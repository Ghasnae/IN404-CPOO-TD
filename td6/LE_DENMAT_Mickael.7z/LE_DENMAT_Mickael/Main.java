/**
  * Class Main
  */
public class Main {
  public static void main(String[] args) {

    SaisieRPN test = new SaisieRPN();
    // test.saisie();
    test.saisie2();
  }
}
