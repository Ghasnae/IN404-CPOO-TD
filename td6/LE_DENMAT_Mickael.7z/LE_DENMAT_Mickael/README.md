@author LE DENMAT Mickael TD4 21804355

This archive contains:
  A README:    That you are reading.
  A Makefile:  For execute and compile, for compile tape "make" in the terminal
  A Main.java, SaisieRPN.java, MoteurRPN.java, Operation.java, StackDouble.java: with javadoc for all functions
  For see all test, open SaisieRPN.java
